import java.util.*;

class Student {

    String name;
    int marks;

    // Constructor
    Student(String name, int marks) {
        this.name = name;
        this.marks = marks;
    }

    // Grade method
    String getGrade() {

        if (marks >= 80)
            return "A";
        else if (marks >= 70)
            return "B";
        else if (marks >= 50)
            return "C";
        else
            return "F";
    }
}

public class Main {

    public static void main(String[] args) {

        // 6 Student objects
        Student[] students = {
            new Student("Ali", 85),
            new Student("Saud", 72),
            new Student("Ahmed", 45),
            new Student("Usman", 91),
            new Student("Hamza", 58),
            new Student("Bilal", 39)
        };

        // Display students
        System.out.println("Student Details:");

        for (Student s : students) {

            String result = (s.marks >= 50) ? "Pass" : "Fail";

            System.out.println(
                s.name + " - Marks: " + s.marks +
                " - Grade: " + s.getGrade() +
                " - " + result
            );
        }

        // filter = passing students
        List<Student> passingStudents = Arrays.stream(students)
                .filter(s -> s.marks >= 50)
                .toList();

        // map = only names
        List<String> passingNames = passingStudents.stream()
                .map(s -> s.name)
                .toList();

        System.out.println("\nPassing Names: " + passingNames);

        // reduce = total marks
        int totalMarks = Arrays.stream(students)
                .map(s -> s.marks)
                .reduce(0, (a, b) -> a + b);

        // Average
        double average = (double) totalMarks / students.length;

        System.out.println("Class Average: " + average);

        // Sort highest marks first
        Arrays.sort(students, (a, b) -> b.marks - a.marks);

        // Top scorer
        Student topStudent = students[0];

        System.out.println("Top Scorer: " + topStudent.name);
    }
}